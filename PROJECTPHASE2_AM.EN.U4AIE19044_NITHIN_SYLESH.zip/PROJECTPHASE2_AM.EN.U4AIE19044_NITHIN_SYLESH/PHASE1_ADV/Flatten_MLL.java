import java.util.Scanner;

class Flatten_MLL {
    static Node head;
    Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        new Scanner(System.in);
        Flatten_MLL list = new Flatten_MLL();
        System.out.println("Enter the first list");
        head = list.createArray();
        head = list.recList(head);
        list.flatten(head);
        list.printList(head);
    }

    Node createArray() {
        System.out.println("Enter the numbers in the list as space separated digits");
        String[] s = sc.nextLine().split(" ");
        int[] a = new int[s.length];
        for (int i = 0; i < s.length; i++) {
            a[i] = Integer.parseInt(s[i]);
        }
        return createList(a, a.length);
    }

    Node createList(int[] arr, int n) {
        Node node = null;
        Node p = null;
        int i;
        for (i = 0; i < n; ++i) {
            if (node == null) {
                node = p = new Node(arr[i]);
            } else {
                p.next = new Node(arr[i]);
                p = p.next;
            }
            p.next = p.child = null;
        }
        return node;
    }

    void printList(Node node) {
        while (node != null) {
            System.out.print(node.data + " ");
            node = node.next;
        }
        System.out.println("");
    }


    void flatten(Node node) {
        if (node == null) {
            return;
        }

        Node tmp;
        Node tail = node;
        while (tail.next != null) {
            tail = tail.next;
        }

        Node cur = node;
        while (cur != tail) {
            if (cur.child != null) {
                tail.next = cur.child;
                tmp = cur.child;
                while (tmp.next != null) {
                    tmp = tmp.next;
                }
                tail = tmp;
            }
            cur = cur.next;
        }
    }

    Node recList(Node node) {
        if (node == null)
            return null;

        Node last = node;

        Node next = node.next;

        System.out.println("Does " + node.data + " have a child? (y/n)");
        String ch = sc.nextLine();
        if (ch.equals("y")) {
            node.child = createArray();
            node.child = recList(node.child);
        }

        if (next != null)
            last.next = recList(next);

        return node;
    }

    static class Node {
        int data;
        Node next, child;

        Node(int d) {
            data = d;
            next = child = null;
        }
    }

}
