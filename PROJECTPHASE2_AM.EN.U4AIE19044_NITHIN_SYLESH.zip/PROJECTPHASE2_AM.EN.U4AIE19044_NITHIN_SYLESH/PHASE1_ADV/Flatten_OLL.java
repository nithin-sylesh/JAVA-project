import java.util.Scanner;

class Flatten_OLL {
    static int cnt = 0;
    Node head;

    static class Node {
        int data;
        Node next, down;

        Node(int data) {
            this.data = data;
            next = null;
            down = null;
        }
    }

    Node flatten(Node first) {
        if (first == null || first.next == null)
            return first;

        first.next = flatten(first.next);
        first = join(first, first.next);

        return first;
    }

    Node push(Node temp, int data) {
        Node node = new Node(data);
        node.down = temp;

        temp = node;
        return temp;
    }

    Node join(Node a, Node b) {
        if (a == null) return b;
        if (b == null) return a;

        Node res;
        if (a.data < b.data) {
            res = a;
            res.down = join(a.down, b);
        } else {
            res = b;
            res.down = join(a, b.down);
        }

        res.next = null;
        return res;
    }

    void printList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.down;
        }
        System.out.println();
    }

    static Flatten_OLL makeList(String[] ar) {
        Flatten_OLL L = new Flatten_OLL();
        L.head = L.push(L.head, Integer.parseInt(ar[0]));
        Node temp = L.head;
        for (int i = 1; i < ar.length; i++) {
            temp.next = L.push(temp.next, Integer.parseInt(ar[i]));
            temp = temp.next;
        }
        return L;
    }

    static void addList(Flatten_OLL L, String[] ar) {
        Node temp = L.head;
        for (int j = 0; j < cnt; j++) {
            temp = temp.next;
        }
        for (int i = 1; i < ar.length; i++) {
            temp.down = L.push(temp.down, Integer.parseInt(ar[i]));
            temp = temp.down;
        }
        cnt = cnt + 1;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Flatten_OLL L;
        System.out.println("Enter the main list (horizontal)");
        String[] ar1 = sc.nextLine().split(" ");
        int count = ar1.length;
        L = makeList(ar1);
        int i = 0;
        while (count != i) {
            System.out.println("Enter the list under " + ar1[i] + " (including " + ar1[i] + ")");
            String[] ar2 = sc.nextLine().split(" ");
            addList(L, ar2);
            i++;
        }
        L.head = L.flatten(L.head);
        L.printList();
    }
}