public class BinarySearchTree{
    static class Node {
        Person data;
        Node left;
        Node right;

        public Node(Person item) {
            data = item;
            left = right = null;
        }
    }

    Node root;

    BinarySearchTree() {
        root = null;
    }

    void insert(Person p) {
        root = insertRec(root, p);
    }

    Node insertRec(Node root, Person p) {
        if (root == null) {
            root = new Node(p);
            return root;
        }
        int result = p.getName().compareTo(root.data.getName());
        if (result < 0)
            root.left = insertRec(root.left, p);
        else if (result > 0)
            root.right = insertRec(root.right, p);
        else {
            System.out.println("This name has already been entered.");
        }
        return root;
    }

    public Person search(String name) {
        Node s = searchRec(root, name);
        if(s!=null){
            System.out.println("Search completed successfully");
            return s.data;
        }
        else {
            System.out.println("Search failed");
            return null;
        }
    }

    public Node searchRec(Node root, String name) {
        if (root == null || root.data.getName().equals(name))
            return root;
        int result = name.compareTo(root.data.getName());
        if (result < 0)
            return searchRec(root.left, name);
        return searchRec(root.right, name);
    }

    void Display() {
        DisplayRec(root);
    }

    public void DisplayRec(Node root) {
        if (root != null) {
            DisplayRec(root.left);
            root.data.display();
            DisplayRec(root.right);
        }
    }

    void Display_first() {
        Person temp = root.data;
        while (root.left != null) {
            temp = root.left.data;
            root = root.left;
        }
        temp.display();

    }

    void Display_last() {
        Person temp = root.data;
        while (root.right != null) {
            temp = root.right.data;
            root = root.right;
        }
        temp.display();
    }

}

