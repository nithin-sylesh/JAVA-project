import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class FileReading{
    public ArrayList<Person> input(String path) {
        Person per;
        ArrayList<Person> p = new ArrayList<Person>();
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            String currentLine = br.readLine();
            while (currentLine != null) {
                String[] arr = currentLine.split(" ");
                per = new Person(arr[0], arr[1], arr[2]);
                p.add(per);
                currentLine = br.readLine();
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return p;
    }
}
