import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Main {
    public static phoneBook book = new phoneBook();
    public static BinarySearchTree bst = book.getphonebook();
    public static FileReading fil = new FileReading();


    public static void main(String[] args) throws IOException {

        BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));

        while (true) {
            System.out.println("Please choose a option :");
            System.out.println("1.Input data using text file");
            System.out.println("2.Add a person");
            System.out.println("3.Find a Person");
            System.out.println("4.Display all contacts");
            System.out.println("5.Display first contact");
            System.out.println("6.Display last contact");
            System.out.println("7.Quit");

            int choice = Integer.parseInt(sc.readLine());

            switch (choice) {
                case 1 : {
                    System.out.println("Enter path of text file including filename");
                    String path = sc.readLine();
                    ArrayList<Person> per = fil.input(path);
                    for (Person p : per) {
                        bst.insert(p);
                    }
                }
                case 2 : {
                    System.out.println("Please enter person name, phone number and email to add");
                    String name = sc.readLine();
                    String phone = sc.readLine();
                    String email = sc.readLine();

                    String personname;
					Person p = new Person(name, phone ,  email);
                    bst.insert(p);
                }
                case 3 : {
                    System.out.println("Please enter a person name to find");
                    String name = sc.readLine();
                    Person p = bst.search(name);
                    System.out.println("Details of " + name + " is : ");
                    if(p!=null)
                        p.display();
                }
                case 4 : {
                    bst.Display();
                }
                case 5 : {
                    bst.Display_first();
                }
                case 6 : {
                    bst.Display_last();
                }
                case 7 : {
                }
                default : System.out.println("Please enter a valid choice");
            }
            if (choice == 7)
                break;
        }
    }
}



