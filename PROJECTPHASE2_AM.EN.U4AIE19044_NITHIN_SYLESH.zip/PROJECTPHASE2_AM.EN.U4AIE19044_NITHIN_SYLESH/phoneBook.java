public class phoneBook {
    BinarySearchTree phonebook = new BinarySearchTree();

    public BinarySearchTree getphonebook() {
        return phonebook;
    }
}
