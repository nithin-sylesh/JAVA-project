public class Person {
    String name;
    String phonenumber;
    String email;

    public Person(String personname, String personphonenumber, String personemail) {
        name = personname;
        phonenumber = personphonenumber;
        email = personemail;
    }

    public String getName() {
        return name;
    }

    public void display() {
        System.out.print(this.name + " ");
        System.out.print(this.phonenumber + " ");
        System.out.println(this.email);
    }
}
